import { defineStore } from 'pinia'
import { rooms, tenants, hostelPayments } from '@/data/mock'
import type { Room, Tenant, HostelPayment, RoomStatus } from '@/types'
import { useSyncStore } from './sync'

export const useHostelStore = defineStore('hostel', {
  state: () => ({
    rooms: rooms as Room[],
    tenants: tenants as Tenant[],
    payments: hostelPayments as HostelPayment[],
  }),
  getters: {
    roomStatus: () => (room: Room): RoomStatus => {
      if (room.occupants === 0) return 'VACANT'
      if (room.occupants < room.capacity) return 'PARTIAL'
      return 'OCCUPIED'
    },
    tenantByRoom: (state) => (roomId: string) => state.tenants.filter((t) => t.roomId === roomId),
    paymentFor: (state) => (tenantId: string) => state.payments.find((p) => p.tenantId === tenantId),
    occupiedCount: (state) => state.rooms.filter((r) => r.occupants >= r.capacity).length,
    vacantCount: (state) => state.rooms.filter((r) => r.occupants === 0).length,
    outstandingBalance: (state) =>
      state.payments.reduce((sum, p) => sum + Math.max(0, p.expectedAmount - p.amountPaid), 0),
    paymentsReceivedThisMonth: (state) => state.payments.reduce((sum, p) => sum + p.amountPaid, 0),
  },
  actions: {
    recordPayment(tenantId: string, amount: number, method: HostelPayment['paymentMethod']) {
      const payment = this.payments.find((p) => p.tenantId === tenantId)
      if (!payment) return
      // optimistic local update — this is what the SQLite write looks like in the real app
      payment.amountPaid = Math.min(payment.expectedAmount, payment.amountPaid + amount)
      payment.paymentMethod = method
      payment.paymentDate = new Date().toISOString().slice(0, 10)
      useSyncStore().queueChange()
    },
  },
})
