import { defineStore } from 'pinia'
import { groceryProducts, grocerySales } from '@/data/mock'
import type { GroceryProduct, Sale, SaleLineItem, PaymentMethod } from '@/types'
import { uid } from '@/types'
import { useSyncStore } from './sync'

export const useGroceryStore = defineStore('grocery', {
  state: () => ({
    products: groceryProducts as GroceryProduct[],
    sales: grocerySales as Sale[],
  }),
  getters: {
    todaysSales: (state) => state.sales.filter((s) => s.date === '2026-09-10' && s.status === 'COMPLETED'),
    todaysRevenue(): number {
      return this.todaysSales.reduce((sum: number, s: Sale) => sum + s.total, 0)
    },
    lowStock: (state) => state.products.filter((p) => p.currentStock <= p.lowStockLevel),
  },
  actions: {
    addStock(productId: string, quantity: number) {
      const product = this.products.find((p) => p.id === productId)
      if (!product) return
      product.currentStock += quantity
      useSyncStore().queueChange()
    },
    completeSale(items: SaleLineItem[], paymentMethod: PaymentMethod, cashier: string) {
      const total = items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0)
      const sale: Sale = {
        id: uid('GS'),
        date: '2026-09-10',
        time: new Date().toTimeString().slice(0, 5),
        items,
        total,
        paymentMethod,
        status: 'COMPLETED',
        cashier,
        syncStatus: 'PENDING',
      }
      this.sales.unshift(sale)
      for (const line of items) {
        const product = this.products.find((p) => p.id === line.itemId)
        if (product) product.currentStock = Math.max(0, product.currentStock - line.quantity)
      }
      useSyncStore().queueChange()
      return sale
    },
  },
})
