import { defineStore } from 'pinia'
import { foodItems, dailyFoodRecords, menuItems, restaurantSales } from '@/data/mock'
import type { FoodItem, DailyFoodRecord, MenuItem, Sale, SaleLineItem, PaymentMethod } from '@/types'
import { uid } from '@/types'
import { useSyncStore } from './sync'

export const useRestaurantStore = defineStore('restaurant', {
  state: () => ({
    foodItems: foodItems as FoodItem[],
    dailyFoodRecords: dailyFoodRecords as DailyFoodRecord[],
    menuItems: menuItems as MenuItem[],
    sales: restaurantSales as Sale[],
  }),
  getters: {
    todaysSales: (state) => state.sales.filter((s) => s.date === '2026-09-10' && s.status === 'COMPLETED'),
    todaysRevenue(): number {
      return this.todaysSales.reduce((sum: number, s: Sale) => sum + s.total, 0)
    },
    todaysFoodCost: (state) =>
      state.dailyFoodRecords.filter((r) => r.date === '2026-09-10').reduce((sum, r) => sum + r.cost, 0),
    bestSeller(): string {
      const counts = new Map<string, number>()
      for (const sale of this.todaysSales) {
        for (const item of sale.items) {
          counts.set(item.name, (counts.get(item.name) ?? 0) + item.quantity)
        }
      }
      let top = '—'
      let max = 0
      for (const [name, qty] of counts) {
        if (qty > max) {
          max = qty
          top = name
        }
      }
      return top
    },
  },
  actions: {
    completeSale(items: SaleLineItem[], paymentMethod: PaymentMethod, cashier: string) {
      const total = items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0)
      const sale: Sale = {
        id: uid('RS'),
        date: '2026-09-10',
        time: new Date().toTimeString().slice(0, 5),
        items,
        total,
        paymentMethod,
        status: 'COMPLETED',
        cashier,
        syncStatus: 'PENDING',
      }
      this.sales.unshift(sale)
      useSyncStore().queueChange()
      return sale
    },
    addFoodRecord(foodItemId: string, quantity: number, cost: number) {
      this.dailyFoodRecords.unshift({
        id: uid('D'),
        date: '2026-09-10',
        foodItemId,
        quantity,
        cost,
      })
      useSyncStore().queueChange()
    },
  },
})
