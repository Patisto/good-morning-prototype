import { defineStore } from 'pinia'

export type ConnectionState = 'ONLINE' | 'OFFLINE'

export const useSyncStore = defineStore('sync', {
  state: () => ({
    connection: 'ONLINE' as ConnectionState,
    pendingCount: 1, // seeded from the one PENDING mock sale
  }),
  actions: {
    toggleConnection() {
      this.connection = this.connection === 'ONLINE' ? 'OFFLINE' : 'ONLINE'
    },
    queueChange() {
      this.pendingCount += 1
    },
    // simulate the background sync engine draining the queue
    flushIfOnline() {
      if (this.connection === 'ONLINE' && this.pendingCount > 0) {
        setTimeout(() => {
          this.pendingCount = 0
        }, 900)
      }
    },
  },
})
