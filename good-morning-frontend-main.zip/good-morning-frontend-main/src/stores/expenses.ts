import { defineStore } from 'pinia'
import { expenses } from '@/data/mock'
import type { Expense } from '@/types'
import { uid } from '@/types'
import { useSyncStore } from './sync'

export const useExpensesStore = defineStore('expenses', {
  state: () => ({
    items: expenses as Expense[],
  }),
  getters: {
    total: (state) => state.items.reduce((sum, e) => sum + e.amount, 0),
    byBusiness: (state) => (business: Expense['business']) =>
      state.items.filter((e) => e.business === business).reduce((sum, e) => sum + e.amount, 0),
  },
  actions: {
    add(expense: Omit<Expense, 'id'>) {
      this.items.unshift({ ...expense, id: uid('E') })
      useSyncStore().queueChange()
    },
  },
})
